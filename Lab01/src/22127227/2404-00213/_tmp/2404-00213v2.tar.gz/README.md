# Readme

This paper studies the injection of new knowledge into LLMs via supervised fine-tuning through two dataset generation strategies, token-based Q&A synthesis and fact-based Q&A synthesis. 